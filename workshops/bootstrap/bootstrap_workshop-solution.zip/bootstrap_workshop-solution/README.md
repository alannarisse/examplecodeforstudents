# bootstrap_workshop
These are the files for the Thinkful Bootstrap workshop. The starter files can be found on the master branch, and a sample solution can be found on the solution branch.